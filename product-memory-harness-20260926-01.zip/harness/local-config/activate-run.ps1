param(
    [switch]$RetainAtlasHandoff
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$runRoot = "C:\Users\Jason\Documents\Jason\Orchestrator_Harness-Bench-Testing\root_runs\product-memory-harness-20260926-01"
$credentialRoot = "C:\Users\Jason\Documents\Jason\Orchestrator_Harness-Bench-Testing\.secrets\creds"
$mongoCredentialPath = Join-Path $credentialRoot "MongoDB.txt"
$deepInfraCredentialPath = Join-Path $credentialRoot "DeepInfra.txt"

foreach ($requiredPath in @($runRoot, $mongoCredentialPath, $deepInfraCredentialPath)) {
    if (-not (Test-Path -LiteralPath $requiredPath)) {
        throw "Required run input is missing: $requiredPath"
    }
}

$mongoUri = Get-Content -LiteralPath $mongoCredentialPath |
    ForEach-Object { $_.Trim() } |
    Where-Object { $_ -match '^mongodb(?:\+srv)?://' } |
    Select-Object -First 1
if (-not $mongoUri) {
    throw "MongoDB.txt does not contain a MongoDB URI"
}

$deepInfraApiKey = Get-Content -LiteralPath $deepInfraCredentialPath |
    ForEach-Object { $_.Trim() } |
    Where-Object { $_ -and -not $_.StartsWith('#') } |
    Select-Object -First 1
if (-not $deepInfraApiKey) {
    throw "DeepInfra.txt does not contain an API key"
}

$runtimeRoot = Join-Path $runRoot "runtime"
$atlasRuntimeRoot = Join-Path $runtimeRoot "atlas"
$everOsRoot = Join-Path $runtimeRoot "memory\everos\everos-4af261092839b9f9ee11312ee1353fe2"
New-Item -ItemType Directory -Path $atlasRuntimeRoot -Force | Out-Null
New-Item -ItemType Directory -Path $everOsRoot -Force | Out-Null

$env:MEMORY_HARNESS_RUN_ID = "zstd-product-h-h-90m-20260926-02"
$env:MEMORY_HARNESS_RUN_LIVE_ATLAS = "1"
$env:MEMORY_HARNESS_ATLAS_URI = $mongoUri
$env:MEMORY_HARNESS_ATLAS_RUN_TOKEN = "da127c228107466b8e527ac2a53d1c39"
$env:MEMORY_HARNESS_ATLAS_LIVE_DATABASE = "memory_harness_live"
$env:MONGODB_URI = $mongoUri
$env:DEEPINFRA_API_KEY = $deepInfraApiKey
$env:EVEROS_ROOT = $everOsRoot
$env:EVEROS_EMBEDDING__MODEL = "Qwen/Qwen3-Embedding-4B"
$env:EVEROS_EMBEDDING__API_KEY = $deepInfraApiKey
$env:EVEROS_EMBEDDING__BASE_URL = "https://api.deepinfra.com/v1/openai"
$env:MEMORY_HARNESS_EVEROS_APPLICATION = "memory-harness-benchmark"
$env:MEMORY_HARNESS_EVEROS_PROJECT = "zstd-decoder"
$env:MEMORY_HARNESS_EVEROS_NAMESPACE = "zstd-product-h-h-90m-20260926-02"
$env:MEMORY_HARNESS_EVEROS_OWNER = "root-benchmark"

if ($RetainAtlasHandoff) {
    $env:MEMORY_HARNESS_ATLAS_HANDOFF_MANIFEST_PATH = Join-Path $atlasRuntimeRoot "handoff-da127c228107466b8e527ac2a53d1c39.json"
} else {
    Remove-Item Env:\MEMORY_HARNESS_ATLAS_HANDOFF_MANIFEST_PATH -ErrorAction SilentlyContinue
}

[pscustomobject]@{
    run_id = $env:MEMORY_HARNESS_RUN_ID
    atlas_run_token = $env:MEMORY_HARNESS_ATLAS_RUN_TOKEN
    atlas_database = $env:MEMORY_HARNESS_ATLAS_LIVE_DATABASE
    atlas_collection = "trusted_procedures_$($env:MEMORY_HARNESS_ATLAS_RUN_TOKEN)"
    atlas_index = "vector_$($env:MEMORY_HARNESS_ATLAS_RUN_TOKEN)"
    atlas_handoff_retained = [bool]$RetainAtlasHandoff
    everos_root = $env:EVEROS_ROOT
    everos_embedding_model = $env:EVEROS_EMBEDDING__MODEL
    mongodb_credential_loaded = $true
    deepinfra_credential_loaded = $true
}
