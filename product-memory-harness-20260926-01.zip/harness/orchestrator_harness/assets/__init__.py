"""Packaged harness assets."""
